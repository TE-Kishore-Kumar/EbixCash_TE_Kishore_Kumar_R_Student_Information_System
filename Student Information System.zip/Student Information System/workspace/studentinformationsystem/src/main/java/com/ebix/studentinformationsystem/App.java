package com.ebix.studentinformationsystem;

public class App {

}
