package com.ebix.studentinformationsystem.exception;

public class StudentException extends RuntimeException{

	public StudentException(String msg) {
		super(msg);
	}
}
